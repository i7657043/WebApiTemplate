﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public interface IExampleApiProvider
    {
        Task<ProviderResponse<List<string>>> GetAsync(int id);
    }
}
