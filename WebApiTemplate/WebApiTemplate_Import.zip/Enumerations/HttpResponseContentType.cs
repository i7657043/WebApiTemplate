﻿namespace $safeprojectname$
{
    public sealed class HttpResponseContentType
    {
        public const string JSON = "application/json";
        public const string HTML = "text/html";
    }
}
