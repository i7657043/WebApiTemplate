﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public interface IExampleApiRepository
    {
        Task<List<string>> GetAsync(int id);
    }
}
